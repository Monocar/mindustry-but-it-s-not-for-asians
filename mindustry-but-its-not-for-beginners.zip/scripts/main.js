// asian difficulty - i would've cried too

// ---- tweak these if you want ----
const SHAKE_INTENSITY = 15;      // screen shake when alpha/beta/gamma shoot
const SHAKE_DURATION = 12;
const BURN_DAMAGE_PER_SEC = 1;   // burning damage on alpha/beta/gamma
const EXPLOSION_RADIUS = 4;      // tiles - only blocks this close get hit
const EXPLOSION_DAMAGE = 150;    // damage to each nearby block

const METEOR_INTERVAL = 30;      // seconds between meteor strikes
const METEOR_DELAY = 120;        // ticks of warning before impact (120 = 2 sec)
const METEOR_RADIUS = 3;         // tiles
const METEOR_DAMAGE = 100;       // damage to units inside the circle
const METEOR_COUNT = 3;          // meteors per strike (first one lands on you)

const BLUE_METEOR_INTERVAL = 60; // seconds between blue meteors
const BLUE_METEOR_RADIUS = 4;    // tiles
const BLUE_METEOR_DAMAGE = 40;   // small damage to the player AND every block inside the circle

function isTroll(u){
    return u.type == UnitTypes.alpha || u.type == UnitTypes.beta || u.type == UnitTypes.gamma;
}

// big centered on-screen text
function say(text, seconds){
    if(Vars.headless) return;
    try{
        Vars.ui.announce(text, seconds);
    }catch(e){
        try{ Vars.ui.showInfoToast(text, seconds); }catch(e2){ Log.err(e2); }
    }
}

// in-game background music: remove every vanilla track (menu music is untouched)
// and use music/unwelcome-school.ogg instead
var bgMusic = null;
try{
    bgMusic = Vars.tree.loadMusic("unwelcome-school");
}catch(e){ Log.err(e); }

function replaceMusic(){
    try{
        var sc = Vars.control.sound;
        sc.ambientMusic.clear();
        sc.darkMusic.clear();
        sc.bossMusic.clear();
        if(bgMusic != null){
            sc.ambientMusic.add(bgMusic);
            sc.darkMusic.add(bgMusic);
            sc.bossMusic.add(bgMusic);
        }
    }catch(e){ Log.err(e); }
}
Events.on(ClientLoadEvent, replaceMusic);
Events.on(WorldLoadEvent, replaceMusic);

// sound that plays every time the player spawns (sounds/koyuki.ogg)
var spawnSound = null;
try{
    spawnSound = Vars.tree.loadSound("koyuki");
}catch(e){ Log.err(e); }
var wasAlive = false;

// custom burning status: 1 hp/sec, looks like normal fire
const slowBurn = new StatusEffect("slow-burn");
slowBurn.damage = BURN_DAMAGE_PER_SEC / 60;   // damage is per tick
slowBurn.effect = Fx.burning;
slowBurn.color = Color.valueOf("ffc455");

// meteor warning circle + falling rock (color and size per meteor type)
function makeMeteorFx(hex, hotHex, radiusTiles){
    var rpx = radiusTiles * 8;
    return new Effect(METEOR_DELAY, 500, e => {
        Draw.z(Layer.effect);

        // danger zone
        Draw.color(Color.valueOf(hex), 0.12 + 0.18 * e.fin());
        Fill.circle(e.x, e.y, rpx);
        Draw.color(Color.valueOf(hex), 0.5 + 0.5 * Mathf.absin(Time.time, 6, 1));
        Lines.stroke(2);
        Lines.circle(e.x, e.y, rpx);

        // shadow grows as the rock gets closer
        Draw.color(Color.black, 0.3);
        Fill.circle(e.x, e.y, 6 * e.fin());

        // the falling rock
        var h = (1 - e.fin()) * 300;
        Draw.color(Color.valueOf(hotHex), 0.6);
        Lines.stroke(5);
        Lines.line(e.x, e.y + h, e.x, e.y + h + 40);
        Draw.color(Color.valueOf("4a4a4a"));
        Fill.circle(e.x, e.y + h, 7);
        Draw.color(Color.valueOf(hotHex));
        Fill.circle(e.x, e.y + h, 3.5);
        Draw.reset();
    });
}
const redMeteorFx = makeMeteorFx("ff2020", "ff9020", METEOR_RADIUS);
const blueMeteorFx = makeMeteorFx("2080ff", "60c0ff", BLUE_METEOR_RADIUS);

// one meteor: warning circle now, impact after METEOR_DELAY ticks
function dropMeteor(fx, radiusTiles, damage, hitBlocks, x, y){
    try{
        var rpx = radiusTiles * 8;
        fx.at(x, y);
        Time.run(METEOR_DELAY, () => {
            try{
                try{ Fx.explosion.at(x, y); }catch(e){}
                try{ Effect.shake(5, 15, x, y); }catch(e){}

                // player units inside the circle
                Groups.unit.each(u => {
                    if(!u.dead && u.isPlayer() && u.within(x, y, rpx + u.hitSize / 2)){
                        u.damage(damage);
                    }
                });

                // blocks inside the circle (blue meteor only)
                if(hitBlocks){
                    var targets = new Seq();
                    Vars.indexer.allBuildings(x, y, rpx, b => { targets.add(b); });
                    targets.each(b => { b.damage(damage); });
                }
            }catch(e){ Log.err(e); }
        });
    }catch(e){ Log.err(e); }
}

// red meteors: METEOR_COUNT around each player, units only
function dropRedMeteors(){
    Groups.player.each(p => {
        if(p.dead()) return;
        var pu = p.unit();
        if(pu == null) return;
        var px = pu.x, py = pu.y;
        for(var i = 0; i < METEOR_COUNT; i++){
            var ox = 0, oy = 0;
            if(i > 0){
                var a = Mathf.random(360);
                var d = Mathf.random(5, 9) * 8;
                ox = Mathf.cosDeg(a) * d;
                oy = Mathf.sinDeg(a) * d;
            }
            var mx = px + ox, my = py + oy;
            Time.run(i * 25, () => dropMeteor(redMeteorFx, METEOR_RADIUS, METEOR_DAMAGE, false, mx, my));
        }
    });
}

// blue meteor: one on each player, hits the player and blocks, small damage
function dropBlueMeteors(){
    Groups.player.each(p => {
        if(p.dead()) return;
        var pu = p.unit();
        if(pu == null) return;
        dropMeteor(blueMeteorFx, BLUE_METEOR_RADIUS, BLUE_METEOR_DAMAGE, true, pu.x, pu.y);
    });
}

// alpha/beta/gamma carry 1 item, every wall has 1 health
function applyStats(){
    try{
        [UnitTypes.alpha, UnitTypes.beta, UnitTypes.gamma].forEach(t => {
            t.itemCapacity = 1;
        });
        Vars.content.blocks().each(b => {
            if(b instanceof Packages.mindustry.world.blocks.defense.Wall){
                b.health = 1;
            }
        });
    }catch(e){ Log.err(e); }
}
Events.on(ContentInitEvent, applyStats);
Events.on(ClientLoadEvent, applyStats);

// every water tile (shallow, deep, sand, tainted...) becomes lava (slag)
function waterToLava(){
    try{
        var w = Vars.world.width(), h = Vars.world.height();
        for(var x = 0; x < w; x++){
            for(var y = 0; y < h; y++){
                var t = Vars.world.tile(x, y);
                if(t != null && t.floor().liquidDrop == Liquids.water){
                    t.setFloor(Blocks.slag);
                }
            }
        }
    }catch(e){ Log.err(e); }
}
Events.on(WorldLoadEvent, waterToLava);

// per-world state
var welcomed = false;
var meteorTimer = 0;
var blueTimer = 0;
Events.on(WorldLoadEvent, e => {
    welcomed = false;
    wasAlive = false;
    meteorTimer = 0;
    blueTimer = 0;
    lastHealth = new ObjectFloatMap();
});

// message the first time you place a wall (once per game launch)
var wallMsgShown = false;
Events.on(BlockBuildEndEvent, e => {
    try{
        if(wallMsgShown || e.breaking || e.unit == null) return;
        if(e.team != Vars.player.team() || e.unit != Vars.player.unit()) return;
        if(e.tile.block() instanceof Packages.mindustry.world.blocks.defense.Wall){
            wallMsgShown = true;
            say("[scarlet]we don't fear our enemies[]", 3);
        }
    }catch(err){ Log.err(err); }
});

// conveyors face the opposite way once built
Events.on(BlockBuildEndEvent, e => {
    try{
        if(e.breaking) return;
        var bd = e.tile.build;
        if(bd == null) return;
        if(!(bd.block instanceof Packages.mindustry.world.blocks.distribution.Conveyor)) return;

        bd.rotation = (bd.rotation + 2) % 4;

        var near = new Seq();
        bd.proximity.each(n => { near.add(n); });
        bd.updateProximity();
        near.each(n => { n.updateProximity(); });
    }catch(err){ Log.err(err); }
});

// small explosion: only damages blocks close by, then kills the unit
function smallBoom(u){
    var x = u.x, y = u.y;
    try{ Fx.explosion.at(x, y); }catch(e){}
    try{ Effect.shake(3, 10, x, y); }catch(e){}
    try{
        var targets = new Seq();
        Vars.indexer.allBuildings(x, y, EXPLOSION_RADIUS * Vars.tilesize, b => { targets.add(b); });
        targets.each(b => { b.damage(EXPLOSION_DAMAGE); });
    }catch(e){ Log.err(e); }
    try{ u.kill(); }catch(e){ Log.err(e); }
}

var lastHealth = new ObjectFloatMap();
var healTick = 0;
var prevBullets = new IntSet();
var mineTimers = {};
var wasMining = {};

Events.run(Trigger.update, () => {
    if(!Vars.state.isGame()) return;

    try{
        // ---- repair nerf: any block heal gives at most +1 hp (host / singleplayer) ----
        if(!Vars.net.client()){
            healTick++;
            var fresh = (healTick % 300 == 0) ? new ObjectFloatMap() : null;
            Groups.build.each(b => {
                var h = b.health;
                var prev = lastHealth.get(b, h);
                if(h > prev + 1 && !(b.block instanceof Packages.mindustry.world.blocks.ConstructBlock)){
                    h = prev + 1;
                    b.health = h;
                }
                lastHealth.put(b, h);
                if(fresh != null) fresh.put(b, h);
            });
            if(fresh != null) lastHealth = fresh;   // drops buildings that no longer exist
        }

        // ---- spawn sound: plays each time the local player goes from dead to alive ----
        if(!Vars.headless && Vars.player != null){
            var alive = !Vars.player.dead();
            if(alive && !wasAlive && spawnSound != null){
                spawnSound.play();
            }
            wasAlive = alive;
        }

        // ---- welcome text when the player first spawns in a world ----
        if(!welcomed && !Vars.headless && Vars.player != null && !Vars.player.dead()){
            welcomed = true;
            say("[scarlet]Welcome to hell, sayang[]", 3);
        }

        // ---- red meteors every 30 sec, blue meteor every 60 sec (host / singleplayer) ----
        if(!Vars.state.isPaused() && !Vars.net.client()){
            meteorTimer += Time.delta;
            if(meteorTimer >= METEOR_INTERVAL * 60){
                meteorTimer = 0;
                dropRedMeteors();
            }
            blueTimer += Time.delta;
            if(blueTimer >= BLUE_METEOR_INTERVAL * 60){
                blueTimer = 0;
                dropBlueMeteors();
            }
        }

        // ---- bullets: scatter in a random direction (not crux) + shake for alpha/beta/gamma ----
        var next = new IntSet();
        var window = Time.delta * 2.5 + 0.01;
        var shake = false;

        Groups.bullet.each(b => {
            if(b.time > window) return;          // only brand new bullets
            next.add(b.id);
            if(prevBullets.contains(b.id)) return;

            if(b.team != Team.crux){
                var ang = Mathf.random(360);
                b.vel.setAngle(ang);
                b.rotation(ang);
            }

            var o = b.owner;
            if(o instanceof Unit && isTroll(o)) shake = true;
        });
        prevBullets = next;

        if(shake && !Vars.headless){
            Vars.renderer.shake(SHAKE_INTENSITY, SHAKE_DURATION);
        }

        // ---- alpha/beta/gamma: permanent burning, mining warning, explode on mining ----
        var nextTimers = {};
        var nextMining = {};
        var exploders = [];
        Groups.unit.each(u => {
            if(u.dead || !isTroll(u)) return;

            u.apply(slowBurn, 20);

            var mining = u.mineTile != null;
            nextMining[u.id] = mining;

            // warning when the local player starts mining
            if(mining && !wasMining[u.id] && !Vars.headless && u == Vars.player.unit()){
                say("[scarlet]NO MINING ALLOWED WITHOUT GOVERNMENT PERMISSION[]", 2);
            }

            // mineTimer drops back to 0 each time an ore is actually mined
            var last = mineTimers[u.id];
            nextTimers[u.id] = u.mineTimer;
            if(!Vars.net.client() && mining && last !== undefined && u.mineTimer < last){
                exploders.push(u);
            }
        });
        mineTimers = nextTimers;
        wasMining = nextMining;

        // explode after the loop so nothing gets modified mid-iteration
        exploders.forEach(u => smallBoom(u));
    }catch(e){
        Log.err(e);
    }
});

// alpha/beta/gamma get a little red tint
Events.run(Trigger.postDraw, () => {
    if(Vars.headless || !Vars.state.isGame()) return;
    try{
        Groups.unit.each(u => {
            if(u.dead || !isTroll(u)) return;
            Draw.mixcol(Color.valueOf("ff2020"), 0.3);
            Draw.rect(u.type.region, u.x, u.y, u.rotation - 90);
            Draw.mixcol();
        });
    }catch(e){ Log.err(e); }
});
